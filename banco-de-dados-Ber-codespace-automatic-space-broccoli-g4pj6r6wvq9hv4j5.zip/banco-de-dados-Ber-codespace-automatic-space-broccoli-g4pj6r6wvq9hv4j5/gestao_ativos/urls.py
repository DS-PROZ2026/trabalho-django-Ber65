from django.urls import path
from . import views

app_name = 'gestao_ativos'

urlpatterns = [
    path('', views.painel_ativos, name='painel_ativos'),
    path('novo/', views.novo_ativo, name='novo_ativo'),
    path('detalhe/<int:ativo_id>/', views.detalhe_ativo, name='detalhe_ativo'),
    path('editar/<int:ativo_id>/', views.editar_ativo, name='editar_ativo'),
    path('remover/<int:ativo_id>/', views.remover_ativo, name='remover_ativo'),
]