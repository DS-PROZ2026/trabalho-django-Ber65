from django.shortcuts import render, get_object_or_404, redirect
from .models import Ativo
from .forms import AtivoForm

def painel_ativos(request):
    """Dashboard principal - Lista todos os ativos"""
    todos_ativos = Ativo.objects.all()
    
    # Estatísticas para o dashboard
    total_ativos = todos_ativos.count()
    ativos_em_uso = todos_ativos.filter(em_uso=True).count()
    ativos_disponiveis = todos_ativos.filter(em_uso=False).count()
    
    contexto = {
        'ativos': todos_ativos,
        'total_ativos': total_ativos,
        'ativos_em_uso': ativos_em_uso,
        'ativos_disponiveis': ativos_disponiveis,
    }
    
    return render(request, 'gestao_ativos/lista_ativos.html', contexto)

def novo_ativo(request):
    """Formulário para cadastrar novo ativo"""
    if request.method == 'POST':
        formulario = AtivoForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('gestao_ativos:painel_ativos')
    else:
        formulario = AtivoForm()
    
    return render(request, 'gestao_ativos/cadastrar_ativo.html', {'formulario': formulario})

def detalhe_ativo(request, ativo_id):
    """Página de detalhes de um ativo específico"""
    ativo = get_object_or_404(Ativo, id=ativo_id)
    return render(request, 'gestao_ativos/detalhe_ativo.html', {'ativo': ativo})

def editar_ativo(request, ativo_id):
    """Editar um ativo existente"""
    ativo = get_object_or_404(Ativo, id=ativo_id)
    
    if request.method == 'POST':
        formulario = AtivoForm(request.POST, instance=ativo)
        if formulario.is_valid():
            formulario.save()
            return redirect('gestao_ativos:painel_ativos')
    else:
        formulario = AtivoForm(instance=ativo)
    
    return render(request, 'gestao_ativos/cadastrar_ativo.html', {'formulario': formulario, 'editando': True})

def remover_ativo(request, ativo_id):
    """Remover um ativo"""
    ativo = get_object_or_404(Ativo, id=ativo_id)
    ativo.delete()
    return redirect('gestao_ativos:painel_ativos')