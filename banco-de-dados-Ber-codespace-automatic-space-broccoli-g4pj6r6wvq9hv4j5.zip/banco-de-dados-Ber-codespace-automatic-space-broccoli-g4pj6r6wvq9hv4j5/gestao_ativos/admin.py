from django.contrib import admin
from .models import Ativo

@admin.register(Ativo)
class AtivoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'numero_patrimonio', 'tipo', 'em_uso')
    list_filter = ('tipo', 'em_uso')
    search_fields = ('nome', 'numero_patrimonio', 'tipo')