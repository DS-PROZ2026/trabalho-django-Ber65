from django.db import models

class Ativo(models.Model):
    nome = models.CharField(max_length=200, verbose_name="Nome do Equipamento")
    numero_patrimonio = models.IntegerField(verbose_name="Número de Patrimônio", unique=True)
    tipo = models.CharField(max_length=100, verbose_name="Tipo de Equipamento")
    em_uso = models.BooleanField(default=False, verbose_name="Está em uso?")
    
    class Meta:
        verbose_name = "Ativo"
        verbose_name_plural = "Ativos"
        ordering = ['numero_patrimonio']
    
    def __str__(self):
        status = "EM USO" if self.em_uso else "DISPONÍVEL"
        return f"{self.nome} | Patrimônio: {self.numero_patrimonio} | {status}"