from django import forms
from .models import Ativo

class AtivoForm(forms.ModelForm):
    class Meta:
        model = Ativo
        fields = ['nome', 'numero_patrimonio', 'tipo', 'em_uso']
        widgets = {
            'nome': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: Notebook Dell Inspiron'
            }),
            'numero_patrimonio': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: 12345'
            }),
            'tipo': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ex: Notebook, Monitor, Impressora'
            }),
            'em_uso': forms.CheckboxInput(attrs={
                'class': 'form-check-input',
                'style': 'width: 20px; height: 20px;'
            }),
        }
    
    def clean_numero_patrimonio(self):
        numero = self.cleaned_data.get('numero_patrimonio')
        if Ativo.objects.filter(numero_patrimonio=numero).exists():
            raise forms.ValidationError("Já existe um ativo com este número de patrimônio!")
        return numero